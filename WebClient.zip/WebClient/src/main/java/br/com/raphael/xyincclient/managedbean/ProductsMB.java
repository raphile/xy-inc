package br.com.raphael.xyincclient.managedbean;

import java.util.List;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import javax.faces.bean.ManagedBean;
import br.com.raphael.xyincclient.model.Products;

@ManagedBean
public class ProductsMB {

	private final String URL_SERVICE = "http://localhost:8080/WebApp/rest/products/";
	private Client client = Client.create();

	public List<Products> getProducts() {
		WebResource wr = client.resource(URL_SERVICE + "getall");

		String json = wr.get(String.class);
		Gson gson = new Gson();
		return gson.fromJson(json, new TypeToken<List<Products>>() {
		}.getType());
	}

}
